Run:
    python3 <queryname>.py <fileName> <arguments-based-on-query>