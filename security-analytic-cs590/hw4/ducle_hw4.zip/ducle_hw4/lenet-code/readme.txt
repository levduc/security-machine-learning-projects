run the code:

python3 lenet.py 0.001
