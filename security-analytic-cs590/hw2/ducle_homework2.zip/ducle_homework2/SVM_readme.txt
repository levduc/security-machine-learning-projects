In SVM task:
- Remove the last 1327 data points in training folder
- Run:
	python ExtractContent
- Put data in TRAINING into processed-training
- Put data in TESTING into processed-testing

- Run:
  python3 SVM.py

- If the code yields an error because of uninstalled dependency. Please install. I used ntlk to get list of stopwords



- duc-spam folder contains instance for task 3.4 