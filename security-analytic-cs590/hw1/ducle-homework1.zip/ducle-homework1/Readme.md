Task1:
    run using:
    python3 task1.py HW1_input.csv attribute name
Task2: 
    run using:
    python3 task2.py HW1_input.csv

Note: the generating heatmap function doesn't work. It crashes. I really appreciate it if TA can provide sample code for generating heatmap.
